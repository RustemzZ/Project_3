# Document

## 2D Charts Usage

### Sensor Memory Monitor (Single Area Chart)

```
function displayMem()
```

### Sensor Docker Issues Monitor (Selectable Scatter Plot)

```
function displayDocker()
```

### Sensor CPU Monitor (Emphasized Pie Chart)


### Sensor Network Monitor (Multi-Object Area Chart)


### Sensor Disk IO Monitor (Line-Area Mixed Chart)


### Single Sensor People Monitor (2D Scatter Map)


### Sensor: People Distance and Duration Monitor (Emphasized Line Chart)


### Sensor Detection Monitor (Aster Plot)


### Sensor People Counting Monitor (Grouped Line-Bar Mixed Chart)


### Docker CPU Monitor (Rectangle Indicator)

## 3D Components Usage

### Three Cubes


### Three Texture Test


### Three Particles and Index Test


### CSS 3D People Monitor Test
